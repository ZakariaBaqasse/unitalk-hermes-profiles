# Equinet A2 Enrichment — Delivery Status and Ordered Roadmap

**Version:** `1.0.1`  
**Updated:** `2026-08-26T08:56:07Z`  
**Profile:** `equinet-a2-enrichment`  
**Current status:** `FOUNDATION DESIGN IN PROGRESS — NOT PILOT-READY`  
**Next delivery gate:** `Step 2I — Canonical Data Contract Review and Promotion`

## 1. Completed and approved foundation work

- **Profile shell — COMPLETED**
  - Isolated profile `equinet-a2-enrichment` created.
  - No cloned A1 identity, memory, broad skills or integrations.
  - Temporary English safety SOUL installed.
  - Live enrichment, CRM access, paid providers, outreach and downstream delivery prohibited.

- **Step 1B: A2 Implementation Contract — COMPLETED / APPROVED FOR FOUNDATION**
  - Current version: `0.1.4`.
  - Mission, scope, users, systems of truth, actions, approval boundaries, audit, errors and integration status defined.
  - A1 scoring ownership and A2-triggered requalification clarified.
  - HubSpot metadata, operational-model and governance confirmations incorporated.
  - No live action authorised.

- **Step 1C: A1-to-A2 Boundary and Handoff Contract — COMPLETED / APPROVED**
  - Contract and JSON Schema version: `1.0.1`.
  - Full immutable A1 candidate snapshot and deterministic integrity hash defined.
  - Approval, eligibility, hold, block, delivery and receipt states defined.
  - Manual no-integration handoff capped at `ready_for_delivery`.
  - A1 score/evidence/approval kept immutable.
  - Requalification signal/return boundary defined.
  - Two valid fixtures and nine negative fixtures created.
  - Deterministic suite: `11/11 PASS`.

- **Step 2A: Canonical Record Design and Field Ownership — COMPLETED / APPROVED**
  - Design version: `0.1.0`.
  - One A2 record lineage per accepted A1 handoff version.
  - Immutable record revisions and append-only evidence/approval/audit history approved.
  - Fourteen canonical sections and ownership boundaries defined.
  - Generic `field_assessments[]` structure approved.
  - Baseline, observations, proposed resolution, human decision and application states separated.
  - A2 evidence namespace and A1 evidence references separated.
  - Field-level and record-level review approved.
  - Nullable connector-controlled external references approved.

- **Step 2B: Field Dictionary and State Model — COMPLETED / APPROVED**
  - Structural dictionary version: `0.1.0`.
  - 216 unique structural paths across all 14 canonical sections.
  - 37 orthogonal state vocabularies and 16 workflow states.
  - Nine negative regressions passed.

- **Step 2C: Requalification and Score-Revision Data Contract — COMPLETED / APPROVED**
  - Contract version: `0.1.1`; four strict schemas remain `0.1.0`.
  - A2 signal, return, A1 score-revision reference and package defined.
  - A2 numeric score production prohibited; A1 remains the deterministic score owner.
  - Fifteen positive and negative cases passed.

- **Step 2D: Canonical A2 JSON Schema — COMPLETED / APPROVED FOR STEP 2E**
  - Approved baseline schema: `1.0.0-draft.1`.
  - All 14 canonical sections required.
  - Every locally defined structural object is strict.
  - Eight dependency hashes and 39 state-vocabulary bindings passed.
  - Seven structural smoke cases passed.
  - Business field catalogue and CRM mappings remain external.
  - Draft.2 correction for relationship-scoped assessment targets was approved through Step 2E decision E13.

## 2. Completed supporting discovery and intake work

- **HubSpot object/property intake — COMPLETED / NO CONNECTION**
  - Data-model image and 950 property definitions parsed.
  - Company, Contact, Deal, Ticket, Complaints and Sample Requests metadata inventoried.
  - Relevant Contact/Company/Deal mapping candidates identified.
  - Read-only, enum and unique-lookup metadata analysed.
  - Horse-count range overlap, duplicate labels and sensitive out-of-scope fields flagged.

- **HubSpot operational metadata intake — COMPLETED / NO CONNECTION**
  - Lifecycle stages, Deal pipeline, custom-object pipelines and status models documented.
  - Users, teams, owners and territories documented.
  - 68 Sales/Marketing process assets analysed: 33 workflows, 32 lists and 3 audit findings.
  - 28 enabled workflows and possible communication/task/status/record side effects identified.
  - No current HubSpot enrichment-review asset found.
  - No owner-assignment or backup-owner rules found.
  - Hard block added for future writes until workflow dependencies are verified.

- **HubSpot object and governance confirmations — COMPLETED**
  - Creator absent.
  - Campaign confirmed as a standard HubSpot object.
  - Complaints and Sample Requests confirmed as custom objects.
  - Super Admins, CRM/business owners, configuration approvers and OAuth approvers recorded.
  - OAuth still ungranted and unconnected.
  - A2 business reviewer and backup remain unconfirmed.

- **Source and field decision pack — DRAFTED / NOT ACTIVATED**
  - Recommended source hierarchy documented.
  - A1-versus-A2 collection boundary clarified.
  - A2 must reuse A1 data and run field-level gap analysis before new research.
  - Detailed 28-row Unitalk working matrix retained internally.
  - Slim 12-row Equinet decision template created.
  - Horse-count range question clarified: no new HubSpot property by default; A2-only category for pilot review.

- **LinkedIn and Apify feasibility — REVIEWED / AUTOMATION BLOCKED**
  - HarvestAPI Company Employees, Profile Search and Profile Scraper Actors reviewed.
  - Technical capability confirmed.
  - LinkedIn terms and Apify Community Actor governance reviewed.
  - Automated use remains `blocked_pending_rights_and_vendor_review`.
  - Recommended pilot route: official site plus authorised human manual LinkedIn role verification.

- **Language and package controls — ACTIVE**
  - Stored A2 profile artifacts are English.
  - French is reserved for implementation conversations with Séverine.
  - Latest language audit passed with zero findings.

## 3. Equinet decisions to collect in parallel

### Required before finalising the business field catalogue

- Confirm target Farrier job roles and priority: Primary, Secondary or Exclude.
- Confirm target Horse Owner organisation job roles and priority.
- Confirm maximum named contacts per prospect and fallback when no target role is found.
- Confirm minimum contactability for A2 review readiness.
- Confirm the horse-count range approach and non-overlapping categories.

### Required before the no-integration pilot

- Confirm personal email and mobile/direct-dial policy.
- Confirm Required, Optional and Do Not Collect Farrier fields.
- Confirm Required, Optional and Do Not Collect Horse Owner fields.
- Confirm manual LinkedIn/social-profile policy.
- Name the A2 business reviewer and backup.
- Approve field-level exceptions for protected data.

### Required before a paid provider test

- Confirm permitted paid lookup types.
- Name the provider and budget approver.
- Approve provider/account/data route and hard credit cap.
- Approve privacy, retention and data-processing route.

### Required before go-live

- Approve owner and territory assignment and backup rules.
- Approve consent, suppression, customer, Deal and sequence eligibility mapping.
- Approve A2-to-HubSpot mapping and protected-field exceptions.
- Confirm Equinet-versus-Mustad business-unit access boundary.
- Approve retention, deletion and administrator-visibility rules.

## 4. Remaining delivery work in required order

### Step 2B — Field Dictionary and State Model — COMPLETED / APPROVED

- Define every canonical structural field.
- Define data types, ownership, mutability and required/nullable rules.
- Define exact state vocabularies for:
  - unknown, not checked, unavailable, not found and error;
  - proposed, verified, partial, gap, conflict and stale;
  - field review and record review;
  - application/sync;
  - requalification and score revisions;
  - duplicate and eligibility checks;
  - `needs_owner_review` and `workflow_dependency_unverified`.
- Add HubSpot status models as external references without making them canonical A2 states.
- Obtain Séverine review and approval.

### Step 2C — Requalification and Score-Revision Data Contract — COMPLETED / APPROVED

- Define exact `requalification_signal` fields.
- Define `requalification_return` payload and states.
- Define A1 score-revision references and lineage.
- Ensure A2 cannot award points or calculate the revised score.
- Add human-review and audit requirements.

### Step 2D — Canonical A2 JSON Schema — COMPLETED / APPROVED FOR STEP 2E

- Strict `a2-enrichment-record.schema.json` created and compiled.
- `additionalProperties: false` applied to all locally defined structural objects.
- Nullable future HubSpot/Twenty/n8n/provider references included.
- Mutable field catalogue, source policy and CRM mapping kept outside the schema.
- Baseline `1.0.0-draft.1` was approved for Step 2E. Corrective `1.0.0-draft.2` is included in the Step 2E review; final promotion remains Step 2I.

### Step 2E — Deterministic Cross-Field Validator — COMPLETED / APPROVED FOR STEP 2F

- Validator version `0.1.0` implemented with schema-first fail-closed behaviour.
- Handoff, evidence, entity, relationship, revision, review, application and audit references validated.
- A1 scoring checks reused; A2-calculated score revisions rejected.
- Synthetic/production separation and no-integration ceilings enforced.
- Prior revision required after revision 1; lifecycle transitions and append-only history validated.
- Optional external Field Catalogue key/type checks implemented without embedding the catalogue.
- Corrective schema `1.0.0-draft.2` and Step 2C lifecycle clarification `0.1.1` approved through E13.
- Deterministic suite approved after `59/59 PASS`.

### Step 2F — Fixtures and Regression Tests — COMPLETED / APPROVED FOR STEP 2G

- Sixteen valid Farrier and Horse Owner business scenarios created.
- Gap, conflict, possible duplicate, confirmed duplicate, protected-field and complete requalification paths included.
- Thirteen negative safety and integrity scenarios created with exact expected error counts.
- Scenario-specific business assertions and fixture hashes enforced.
- All fixture records are synthetic and contain zero recorded external-action claims.
- Step 2F suite approved after `29/29 PASS`.

### Step 2G — Handoff-to-Record Initialisation — COMPLETED / APPROVED FOR STEP 2H

- Initialiser CLI version `0.1.0` implemented.
- Complete A1 handoff validation and lossless snapshot preservation enforced.
- Stable A2 lineage/revision/run IDs derived from the complete handoff hash.
- Empty A2 evidence, assessment and requalification containers initialised.
- Integrations unavailable, review pending and every external action disabled.
- Three valid, eight invalid and fifteen deterministic/idempotency controls pass.
- Positive manual no-integration case remains pending an approved real production handoff.
- Step 2G suite approved after `11/11` fixtures and `15/15` controls PASS.

### Step 2H — Review-View Specification — COMPLETED / APPROVED FOR STEP 2I

- Read-only review-view specification `0.1.0` created.
- Markdown, six CSV files and seven-sheet Excel package defined and rendered.
- Current/proposed values, observations, evidence, confidence, freshness, gaps, conflicts, protection and requalification are visible.
- Six representative packages and eleven negative checks pass.
- Canonical JSON remains the sole lossless source; projections contain no reviewer input, formula or external action.
- Step 2H approved after `6/6` sample packages and `11/11` negative checks PASS, including the post-approval carriage-return regression.

### Step 2I — Canonical Data Contract Review and Promotion

- Present synthetic canonical records.
- Record Séverine corrections/approval.
- Promote schema and related artifacts atomically to `1.0.0`.
- Create acceptance record and rerun all tests.

### Step 3A — Business Field Catalogue

- Finalise canonical business field keys.
- Apply Equinet job-role and field-priority decisions.
- Define Farrier and Horse Owner fields as Required, Optional or Do Not Collect.
- Define maximum stakeholders and minimum contactability.
- Define horse-count exact/range handling.

### Step 3B — Minimum Data Packages

- Define A2 review-ready package by segment.
- Keep outreach-ready package separate.
- Define missing-field behaviour and exceptions.
- Require human approval during pilot.

### Step 3C — A2 Source Register

- Create an A2-specific source register; do not reuse A1 automation permissions automatically.
- Record source purpose, fields, manual/assisted/API access, evidence strength, rights, limits and stop conditions.
- Reuse A1 evidence before new source calls.
- Keep LinkedIn automation blocked unless rights/vendor approval changes.

### Step 3D — Evidence, Verification, Confidence and Freshness Policies

- Define field-level proof and verification rules.
- Define Verified/High/Medium/Low/Partial/Gap/Conflict.
- Define freshness windows and event-based rechecks.
- Define source independence and corroboration.
- Add deterministic calculations and tests.

### Step 3E — Protected Fields and Conflict Policy

- Pin exact protected HubSpot fields and manual-value rules.
- Define preserve/propose/hold/reject behaviour.
- Define field-level approval exceptions.
- Validate workflow/list dependency risk before any future write.

### Step 3F — Provider and Cost Policy

- Measure gaps after no-provider testing.
- Select only necessary provider categories.
- Run approved fixed-dataset benchmark after budget approval.
- Define credit caps, retries, idempotency, provenance and deletion.

### Step 3G — Preliminary A2-to-HubSpot Mapping

- Map canonical keys to Contact, Company and Deal internal names.
- Define read, propose and approved-write direction.
- Define enum conversion, protected status, conflict and failure behaviour.
- Create workflow-dependency register.
- Keep mapping proposed until live read-only verification.

### Step 4 — Final Specialist SOUL

- Replace temporary scaffold after foundations are validated.
- Reference versioned contracts/configurations rather than duplicating mutable values.
- Preserve mission, workflow, non-goals, source precedence, approval, escalation and error boundaries.
- Run static SOUL validation and profile health check.

### Step 5 — Operational Skills and Scripts

- Design complete skill family, then build in dependency waves.
- Wave 1: handoff intake, entity resolution, duplicate/eligibility review.
- Wave 2: gap plan, permitted enrichment research, contact/professional/equine verification.
- Wave 3: evidence/confidence, protected-field conflict handling, data quality, review package and handoffs.
- Add deterministic normalisation, validation, reconciliation and export scripts.
- Use one business checkpoint per wave.

### Step 6 — Model, Tools, Permissions and Quotas

- Select primary/fallback model through Unitalk gateway.
- Confirm provider region, retention/training and governance.
- Set minimal default tool allowlist and conditional tools.
- Set source, candidate, call, retry, concurrency and cost controls.
- Keep HubSpot, paid providers, LinkedIn automation and external actions disabled until approved and connected.

### Step 7 — Synthetic End-to-End Acceptance

- Test Farrier and Horse Owner records.
- Include gaps, conflicts, possible duplicates and requalification.
- Test prohibited requests and action boundaries.
- Validate JSON, Markdown, CSV and Excel outputs.
- Measure model/API usage.

### Step 8 — Bounded Real No-Integration Pilot

- Use a small approved set of A1 candidates.
- Reuse A1 evidence first.
- Run targeted source checks only for approved gaps/conflicts/freshness.
- Use no HubSpot writes, outreach, paid provider or automated LinkedIn.
- Require human review for every record.

### Step 9 — Evaluation, Improvement and No-Integration Freeze

- Review quality, coverage, false matches, gaps, time and cost.
- Apply approved corrections.
- Replay accepted records deterministically.
- Package release manifest, runbook, open-items register and safe delivery archive.
- Promote only after approval to `PILOT_READY_NO_INTEGRATION`.

### Step 10 — Integrations

- Configure least-privilege HubSpot read OAuth after approval.
- Verify live metadata, associations, records, fill rates and permissions.
- Finalise A2-to-HubSpot mapping.
- Select/configure Twenty or another review layer.
- Build n8n triggers, waits, approvals, retries, idempotency, notifications and dead-letter handling.
- Configure any approved provider.
- Build A1 requalification, A3 and A14 structured handoffs.
- Build guarded HubSpot write action only after workflow-dependency audit.

### Step 11 — Integrated Pilot

- Run read-only and proposed-patch tests first.
- Test duplicate, customer, Deal, consent, suppression, owner and list states.
- Test approval, write, reconciliation, rollback and duplicate-execution protection in an approved environment.
- Keep all enriched records human-reviewed.

### Step 12 — Production Readiness and Acceptance

- Confirm roles, permissions, approval matrix and operating coverage.
- Confirm monitoring, audit, retention, deletion, incident and cost controls.
- Pass representative quality, safety, integration and rollback tests.
- Obtain recorded Equinet production approval.
- Keep contractual acceptance as a separate milestone.

## 5. Current blockers and non-blockers

- **Not a blocker for Step 2D:** no live HubSpot connection.
- **Not a blocker for Step 2D:** pending Equinet role/field answers; the stable schema uses generic field assessments.
- **Blocks final Business Field Catalogue:** target roles, contact limit, minimum contactability and horse-count taxonomy decisions.
- **Blocks real no-integration pilot:** A2 reviewer/backup, field priorities, source register and privacy decisions.
- **Blocks paid provider testing:** provider/data route/budget approval.
- **Blocks HubSpot integrated pilot:** OAuth, scopes, live verification, associations, mapping and workflow-dependency audit.
- **Blocks production:** complete approval matrix, permissions, monitoring, retention/deletion, audit, failure/rollback and Equinet sign-off.

## 6. Immediate next action

Proceed with **Step 2I — Canonical Data Contract Review and Promotion** while Equinet reviews the slim client decision template in parallel.
