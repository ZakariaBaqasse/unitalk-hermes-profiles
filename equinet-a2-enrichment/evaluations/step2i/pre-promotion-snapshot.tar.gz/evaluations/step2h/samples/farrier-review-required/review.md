# A2 Enrichment Review

**Canonical record:** `A2-STEP2F_FARRIER_001`  
**Revision:** `A2-REV-STEP2F_FARRIER_004`  
**Canonical SHA-256:** `0fb785b79f3d8919a7a99a47d8f84d533df0f52a67fe023e866c65e4d57f2316`  
**Projection status:** `READ-ONLY — NOT A DECISION OR EXTERNAL ACTION`

## Decision Summary

| Segment | Subject | Workflow | Record decision | Data quality | A2 eligibility | A1 score/band | Review items |
|---|---|---|---|---|---|---|---|
| farrier | Jordan Example \| Bluegrass Hoof Care — Synthetic | review_required | pending | review_ready | not_checked | 72 / high | 2 |

## Review Queue

| Priority | Field | Current | Observations | Proposed action | Proposed | Evidence | Confidence | Freshness | Conflict | Protected | Decision |
|---|---|---|---|---|---|---|---|---|---|---|---|
| change | person.business_email | null | [{"claim_type":"direct_fact","confidence_level":"medium","error":null,"evidence_ids":["A2-EV-STEP2F-FARRIER-EMAIL"],"freshness_status":"undated","normalised_value":"farrier@example.com","observation_id":"A2-OBS-FARRIER-EMAIL","raw_value":"farrier@example.com","verification_status":"verified"}] | add | "farrier@example.com" | ["A2-EV-STEP2F-FARRIER-EMAIL"] | medium | undated | none | not_protected | pending |
| change | person.professional_credential | null | [{"claim_type":"direct_fact","confidence_level":"medium","error":null,"evidence_ids":["A2-EV-STEP2F-FARRIER-CREDENTIAL"],"freshness_status":"undated","normalised_value":"Synthetic Certified Farrier","observation_id":"A2-OBS-FARRIER-CREDENTIAL","raw_value":"Synthetic Certified Farrier","verification_status":"verified"}] | add | "Synthetic Certified Farrier" | ["A2-EV-STEP2F-FARRIER-CREDENTIAL"] | medium | undated | none | not_protected | pending |

## Gaps, Conflicts and Limitations

| Missing | Unverified | Conflicts | Stale | Invalid | Limitations |
|---|---|---|---|---|---|
| [] | [] | [] | [] | [] | ["No live source, provider, CRM or workflow connection is authorised."] |

## Requalification

No requalification item is recorded in this revision.

## Evidence Summary

| ID | Namespace | Source | Policy | Reliability | URL | Summary |
|---|---|---|---|---|---|---|
| EV-TEST001 | a1_reference | business_website | approved | high | https://example.com/bluegrass-hoof-care | Synthetic fixture: professional farrier service in Lexington supporting sport-horse clients. |
| A2-EV-STEP2F-FARRIER-EMAIL | a2 | synthetic_business_website | approved | medium | https://example.com/step2f-primary | Synthetic official site publishes a professional email address. |
| A2-EV-STEP2F-FARRIER-CREDENTIAL | a2 | synthetic_business_website | approved | medium | https://example.org/step2f-registry | Synthetic official registry confirms a professional credential. |

## Action Boundaries

- This view is derived from canonical JSON and is not authoritative data storage.
- It does not approve a field, record, score revision, CRM write or outreach action.
- A1 remains the only numeric score-revision producer.
- External actions require the separately authorised workflow and receipt.
