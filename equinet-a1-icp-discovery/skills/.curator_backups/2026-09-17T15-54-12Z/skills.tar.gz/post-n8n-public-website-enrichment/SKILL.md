---
name: post-n8n-public-website-enrichment
version: 3.1.0
status: production_active
description: Process the post-n8n website-candidate lane before Twenty staging.
compatibility: Requires a1.discovery-result.v1, Public Website Enrichment Policy 1.5.0 and the production classification, qualification, confidence and scoring wrappers.
---

# Post-n8n Public Website Enrichment

Use this skill on the website-candidate lane after the compact n8n result is routed and before that lane is staged in Twenty. n8n supplies compact run metadata and leads; Hermes verifies the official website and performs cited evidence collection, classification, qualification, confidence and scoring. Leads without a website candidate bypass this skill and stage unscored. Item-level pre-verification failures may fall back to unscored Company staging; post-verification assessment failures remain non-terminal until a structured non-retryable failure or retry exhaustion is explicitly checkpointed.

## Boundary

Accept the compact `a1.discovery-result.v1` envelope from `Build Final Discovery Result`. Its canonical fields are `contract_version`, top-level `run_id`, and unique `leads[].lead_fingerprint` values. Preserve each lead exactly as supplied. The script accepts the earlier `schema_version`/`run.run_id`/`lead_id` shape only for existing fixtures and migration recovery.

Do not:

- rediscover, broaden, merge or deduplicate n8n leads;
- treat a lead name, category, directory snippet, map result or candidate website as verified evidence;
- call Firecrawl or any web service from the local script;
- generate claims, excerpts, URLs, classifications or criterion statuses in the deterministic script;
- claim HubSpot/Twenty checks, outreach permission or A2 approval.

The script has no Hermes web-tool API and no Firecrawl credentials. Website retrieval is always an agent/tool action.

## Authoritative dependencies

Resolve from the active profile home:

```text
configurations/evidence/public-website-enrichment-policy-v1.yaml
skills/post-n8n-public-website-enrichment/references/enrichment-results.schema.json
skills/post-n8n-public-website-enrichment/scripts/manage_enrichment.py
skills/prospect-segment-classification/scripts/validate_classification.py
skills/equinet-icp-qualification/scripts/build_qualification.py
skills/prospect-evidence-and-confidence/scripts/build_confidence_package.py
skills/icp-scoring-and-rationale/scripts/build_scoring_package.py
```

Use the profile-local `.venv/bin/python`. Provision it outside a run from `configurations/operations/a1-python-runtime-requirements.txt`; do not install packages during a discovery run.

## Routing and overlay commands

Use the deterministic router before enrichment:

```text
.venv/bin/python skills/post-n8n-public-website-enrichment/scripts/route_and_overlay.py route \
  --input <discovery-result.json> --output-dir <two-lane-v1>
```

It writes a routing index, lane-specific discovery envelopes and explicit no-website overlays. `route_and_overlay.py next-action` determines the next durable phase from artifacts. After every website-lane record is `scored`, evidence-backed `terminal_out_of_scope`, `terminal_none_found`, `terminal_verification_failed`, or explicit `terminal_assessment_failed`, build the website overlays and later merge the two verified staging indexes:

```text
.venv/bin/python skills/post-n8n-public-website-enrichment/scripts/route_and_overlay.py build-website-overlays \
  --input <website-candidate-discovery-result.json> --state <enrichment-state.json> \
  --output <website-overlays.json>

.venv/bin/python skills/post-n8n-public-website-enrichment/scripts/route_and_overlay.py validate-overlays \
  --input <website-overlays.json> --source <website-candidate-discovery-result.json>

.venv/bin/python skills/post-n8n-public-website-enrichment/scripts/route_and_overlay.py merge-indexes \
  --input <original-discovery-result.json> \
  --no-website-index <no-website-staging-index.json> \
  --website-index <website-staging-index.json> \
  --output <final-staging-index.json>
```

All command stdout is aggregate-only. The JSON artifacts are authoritative.

## Checkpoint workflow

1. Initialise `a1.website-enrichment-state.v2` from the unchanged website-lane discovery result:

```text
.venv/bin/python skills/post-n8n-public-website-enrichment/scripts/manage_enrichment.py init \
  <website-candidate-discovery-result.json> --state <state.json> --max-retries 2
```

Every lead starts as `research_pending` with immutable source data, revision `0`, no claim and no synthetic evidence.

2. Ask for one phase-specific batch. The command returns only the highest-priority unfinished phase unless `--phase` is supplied:

```text
.venv/bin/python skills/post-n8n-public-website-enrichment/scripts/manage_enrichment.py next \
  --state <state.json> --batch-size 5 --phase research
```

3. Before working on an item, claim it using the returned revision:

```text
.venv/bin/python skills/post-n8n-public-website-enrichment/scripts/manage_enrichment.py claim \
  --state <state.json> --lead-id <fingerprint> --owner <job-id> \
  --lease-seconds 900 --expected-revision <revision>
```

Only the matching owner and lease ID may submit the result. Expired claims are recoverable; stale revisions and concurrent claims are rejected.

4. Research with approved web tools. `web_search` may locate a destination; retained evidence must come from `web_extract` on the verified official domain. Submit exactly one `a1.website-enrichment-research-results.v2` record using `accept`, with owner, lease ID and claimed revision. Research submissions contain website evidence only. A verified result moves to `assessment_pending`; it is not terminal. A researched `none_found` result moves to `terminal_none_found`. Missing n8n website candidates never enter this state machine and remain labelled `website_candidate_not_provided` in the direct lane.

5. Request and claim the assessment phase, then submit `a1.website-enrichment-assessment-submissions.v2`:

```text
.venv/bin/python skills/post-n8n-public-website-enrichment/scripts/manage_enrichment.py next \
  --state <state.json> --batch-size 5 --phase assessment

.venv/bin/python skills/post-n8n-public-website-enrichment/scripts/manage_enrichment.py submit-assessment \
  --state <state.json> --submission <assessment.json> \
  --owner <job-id> --lease-id <lease-id> --expected-revision <claimed-revision>
```

A normal submission requires evidence-linked classification, qualification and confidence objects. Insufficient facts use explicit `unknown` criterion states rather than omitted objects. An `out_of_scope` classification is terminal only when it cites accepted evidence and contains no fabricated downstream assessments.

6. Record research, assessment or scoring failures only while holding the matching claim:

```text
.venv/bin/python skills/post-n8n-public-website-enrichment/scripts/manage_enrichment.py fail \
  --state <state.json> --lead-id <fingerprint> --failure-code <snake_case_code> \
  --error <message> --attempted-at <ISO-8601> --owner <job-id> \
  --lease-id <lease-id> --expected-revision <claimed-revision> [--retryable]
```

Non-retryable or exhausted research failures become `terminal_verification_failed`. Non-retryable or exhausted assessment/scoring failures become `terminal_assessment_failed` and retain verified website evidence. Deterministic schema/configuration failures enter operator repair rather than looping indefinitely. A separate `fallback` command exists only for audited recovery and requires attempts beyond the configured retry limit plus `retries_exhausted: true`.

7. Score ready records. `run-ready` claims and checkpoints each lead independently:

```text
.venv/bin/python skills/post-n8n-public-website-enrichment/scripts/manage_enrichment.py run-ready \
  --state <state.json> --output-dir <artifacts-dir> --lead-id <fingerprint> \
  --owner <job-id> --lease-seconds 900
```

It validates classification, builds qualification, calculates confidence, prepares scoring input, executes deterministic scoring and records artifact paths. It never invents missing inputs. Wrapper failures are recorded with structured failure codes and bounded retry behaviour.

8. Build website overlays only when the v2 summary reports `build_overlays`. Allowed terminal outcomes are `scored`, evidence-backed `terminal_out_of_scope`, `terminal_none_found`, `terminal_verification_failed`, and explicit `terminal_assessment_failed`. Pending or unexplained verified-unscored records block overlay generation and Twenty staging.

9. For historical v1 state, create a separate migration artifact:

```text
.venv/bin/python skills/post-n8n-public-website-enrichment/scripts/migrate_state_v1_to_v2.py \
  --input <v1-state.json> --output <new-v2-state.json>
```

Never overwrite the v1 state, rerun n8n, or repeat uncertain Twenty writes.

## Evidence rules

- n8n fields are discovery context, not evidence for a confirmed criterion.
- For a verified site, `web_search` identifies destinations only; every retained evidence record must be a `web_extract` destination-page citation.
- A no-site completion carries no retained evidence and cannot support a confirmed classification, qualification criterion, confidence, or score.
- Retain exact excerpts and page URLs for every retained evidence record. A claim must not be stronger than its excerpt.
- Preserve unknowns and contradictions. Never infer horse count, commercial status, ownership, purchasing authority or private contact details.
- Multiple pages on one official domain remain one source for corroboration.
- Publication does not create consent or authorise outreach.

## Handoff

Classification starts only after accepted verified-site enrichment. A no-site completion cannot enter the classification, qualification, confidence, or scoring wrappers, but it must continue to unscored Twenty staging through `evidence-aware-crm-staging` when the unchanged n8n lead has `business_name` or `name`. A cited verified site without accepted assessments is `assessment_pending` and cannot produce an overlay. Only an explicit exhausted assessment failure may retain the verified URL in an unscored overlay. The stager always resolves a Company name as `business_name or name` and also creates one linked Person when `name` is present. Preserve the lead fingerprint, website status, missing information and conflicts. If neither name exists, record `blocked_missing_company_name` rather than inventing one.

### Verified-site assessment failure

Official-site verification and assessment are separate. A verified site is non-terminal in `assessment_pending`, `ready_to_score`, or `scoring`. Overlay v2 retains the official URL without a score only after a structured assessment failure has been marked non-retryable or exhausted through the v2 state machine. Automatic `verified_site_unscored_missing_pipeline_inputs` fallback is forbidden.

For a historical run stopped by the former terminal-state limitation, create a separately named corrective website-lane staging directory linked to the immutable discovery result and accepted enrichment state. Regenerate overlay v2, stage only the website lane, and merge it with the already verified no-website staging index. Do not rerun n8n or repeat completed or uncertain Twenty writes.

## Enrichment state v2 hardening

`a1.website-enrichment-state.v2` separates research, assessment and scoring. A verified official site enters `assessment_pending`; it is never terminal merely because assessment inputs are absent. Workers must claim one lead with owner, lease ID, expiry and expected revision before accepting research, submitting assessment, recording failure or scoring. Research submissions use `a1.website-enrichment-research-results.v2`; assessment submissions are separate and cannot replace accepted website evidence. Only scored, evidence-backed out-of-scope, `none_found`, pre-verification terminal failure, or an explicit exhausted assessment failure can generate website overlays. Migrate v1 with `scripts/migrate_state_v1_to_v2.py` to a separate path; never mutate v1 in place. A missing n8n website candidate is `website_candidate_not_provided`, distinct from research-completed `none_found`.

## Verification

Run:

```text
.venv/bin/python -m unittest -v \
  skills/post-n8n-public-website-enrichment/tests/test_manage_enrichment.py \
  skills/post-n8n-public-website-enrichment/tests/test_route_and_overlay.py
```

Verify that tests cover routing coverage, stable pending batches, evidence rejection, official-domain checks, bounded retries, per-lead scoring checkpoints, overlay null/range semantics, combined-index coverage, atomic checkpoints and real execution of the qualification/confidence/scoring wrappers.
