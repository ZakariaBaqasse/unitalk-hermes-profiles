from __future__ import annotations

import copy
import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

SKILL = Path(__file__).resolve().parents[1]
SCRIPT = SKILL / "scripts" / "route_and_overlay.py"
MANAGE = SKILL / "scripts" / "manage_enrichment.py"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


m = load("manage_enrichment_route_tests", MANAGE)
r = load("route_and_overlay_tests", SCRIPT)


def discovery():
    return {
        "contract_version": "a1.discovery-result.v1", "run_id": "RUN-ROUTE",
        "summary": {"returned": 3},
        "leads": [
            {"lead_fingerprint": "no-site", "business_name": "No Site"},
            {"lead_fingerprint": "website", "business_name": "Website", "website": "https://example.test"},
            {"lead_fingerprint": "invalid", "business_name": "Invalid", "website": "://bad"},
        ],
    }


def website_discovery():
    return {
        "contract_version": "a1.discovery-result.v1", "run_id": "RUN-WEB",
        "leads": [{"lead_fingerprint": "website", "business_name": "Website", "website": "https://example.test"}],
    }


def terminal_state(source, state_name, enrichment, terminal, artifacts=None, pipeline_inputs=None):
    state = m.initialize_state(copy.deepcopy(source), max_retries=1)
    record = state["leads"][source["leads"][0]["lead_fingerprint"]]
    record.update({
        "state": state_name, "claim": None, "enrichment": copy.deepcopy(enrichment),
        "terminal": copy.deepcopy(terminal), "artifacts": copy.deepcopy(artifacts or {}),
        "pipeline_inputs": copy.deepcopy(pipeline_inputs or {}),
    })
    m._validate_state(state)
    return state


class RouteAndOverlayV2Tests(unittest.TestCase):
    def test_route_is_complete_and_no_website_is_explicitly_unscored(self):
        with tempfile.TemporaryDirectory() as root:
            index = r.route_discovery(discovery(), Path(root))
            self.assertEqual(index["counts"], {"no_website": 2, "website_candidate": 1})
            overlays = json.loads((Path(root) / "no-website-overlays.json").read_text())
            by_id = {row["lead_fingerprint"]: row for row in overlays["overlays"]}
            self.assertEqual(by_id["no-site"]["notes"]["fallback_reason"], "website_candidate_not_provided")
            self.assertEqual(by_id["invalid"]["notes"]["fallback_reason"], "invalid_website_candidate")
            self.assertTrue(all(row["icp_score"] is None for row in by_id.values()))

    def test_zero_is_a_real_scored_value(self):
        overlay = {
            "schema_version": r.OVERLAY_SCHEMA, "lead_fingerprint": "website",
            "website_status": "verified", "enrichment_status": "completed",
            "official_website_url": "https://example.test", "qualification_status": "ELIGIBLE",
            "icp_score_status": "SCORED", "icp_score": 0, "icp_band": "UNQUALIFIED",
            "icp_outcome": "unqualified_farrier", "evidence_confidence_score": 80,
            "evidence_confidence_level": "HIGH", "notes": {},
        }
        r.validate_overlay(overlay)
        overlay["icp_score_status"] = "NOT_SCORED"
        overlay["qualification_status"] = "NOT_CHECKED"
        with self.assertRaisesRegex(ValueError, "explicit exhausted|null score"):
            r.validate_overlay(overlay)

    def test_scored_overlay_uses_v2_terminal_state_and_artifacts(self):
        source = website_discovery()
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            qualification = root / "qualification.json"
            confidence = root / "confidence.json"
            scoring = root / "scoring.json"
            qualification.write_text(json.dumps({"qualification": {"exclusion_status": "eligible", "icp_config_version": "2.0.0"}}))
            confidence.write_text(json.dumps({"confidence": {"score": 84, "level": "high", "method_version": "1.2.0", "limitations": []}}))
            scoring.write_text(json.dumps({"scoring": {"status": "scored", "score": 72, "band": "medium", "model_version": "1.1.0", "block_reason": None}, "audit": {"outcome": "qualified_farrier"}}))
            state = terminal_state(
                source, "scored",
                {"website_status": "verified", "official_website_url": "https://example.test", "missing_information": []},
                {"outcome": "scored", "at": "2026-09-10T00:00:00Z"},
                {"qualification_package": str(qualification), "confidence_package": str(confidence), "scoring_package": str(scoring)},
                {"classification_decision": {}, "qualification_assessment": {}, "confidence_assessment": {}},
            )
            overlay = r.build_website_overlays(source, state)["overlays"][0]
            self.assertEqual(overlay["icp_score"], 72)
            self.assertEqual(overlay["icp_band"], "MEDIUM")
            self.assertEqual(overlay["evidence_confidence_level"], "HIGH")

    def test_missing_assessments_are_nonterminal_and_block_overlays(self):
        source = website_discovery()
        state = m.initialize_state(copy.deepcopy(source))
        record = state["leads"]["website"]
        record["state"] = "assessment_pending"
        record["enrichment"] = {
            "website_status": "verified", "official_website_url": "https://example.test",
            "evidence": [{"evidence_id": "EV-TEST1"}], "missing_information": [], "conflicts": [],
        }
        m._validate_state(state)
        with self.assertRaisesRegex(ValueError, "not terminal"):
            r.build_website_overlays(source, state)

    def test_explicit_exhausted_assessment_failure_preserves_domain(self):
        source = website_discovery()
        state = terminal_state(
            source, "terminal_assessment_failed",
            {"website_status": "verified", "official_website_url": "https://example.test", "evidence": [{"evidence_id": "EV-TEST1"}], "missing_information": [], "conflicts": []},
            {"outcome": "assessment_failed", "failure_code": "assessment_schema_failure", "attempted_at": "2026-09-10T00:00:00Z", "attempts": 2, "retries_exhausted": True},
        )
        overlay = r.build_website_overlays(source, state)["overlays"][0]
        self.assertEqual(overlay["official_website_url"], "https://example.test")
        self.assertEqual(overlay["enrichment_status"], "failed")
        self.assertEqual(overlay["icp_score_status"], "NOT_SCORED")
        self.assertEqual(overlay["notes"]["outcome_provenance"]["outcome"], "assessment_failed")

    def test_unexplained_verified_not_scored_is_rejected(self):
        overlay = {
            "schema_version": r.OVERLAY_SCHEMA, "lead_fingerprint": "website",
            "website_status": "verified", "enrichment_status": "completed",
            "official_website_url": "https://example.test", "qualification_status": "NOT_CHECKED",
            "icp_score_status": "NOT_SCORED", "icp_score": None, "icp_band": None,
            "icp_outcome": None, "evidence_confidence_score": None,
            "evidence_confidence_level": None, "notes": {},
        }
        with self.assertRaisesRegex(ValueError, "explicit exhausted"):
            r.validate_overlay(overlay)

    def test_out_of_scope_is_blocked_not_unexplained_unscored(self):
        source = website_discovery()
        state = terminal_state(
            source, "terminal_out_of_scope",
            {"website_status": "verified", "official_website_url": "https://example.test", "evidence": [{"evidence_id": "EV-TEST1"}], "missing_information": [], "conflicts": []},
            {"outcome": "out_of_scope", "at": "2026-09-10T00:00:00Z", "failure_code": None},
            pipeline_inputs={"classification_decision": {"classification_status": "out_of_scope", "evidence_references": ["EV-TEST1"]}},
        )
        overlay = r.build_website_overlays(source, state)["overlays"][0]
        self.assertEqual(overlay["icp_score_status"], "BLOCKED")
        self.assertEqual(overlay["qualification_status"], "EXCLUDED")
        self.assertEqual(overlay["icp_outcome"], "out_of_scope")

    def test_merge_requires_clean_website_provenance_and_exact_coverage(self):
        source = website_discovery()
        lane_source = r.subset_discovery(source, source["leads"], "website_candidate")
        provenance = {
            "schema_version": "a1.website-overlay-provenance.v1",
            "source_sha256": r.sha256_json(lane_source), "overlay_count": 1,
            "verified_unscored_count": 1, "explicit_exhausted_assessment_failure_count": 1,
            "unexplained_verified_unscored_count": 0,
        }
        item = {
            "lead_fingerprint": "website", "status": "company_staged_no_person_required",
            "company_id": "company-1", "person_required": False, "person_id": None,
            "person_disposition": "not_required", "relation_status": "not_required",
            "company_reconciliation_artifact": "/tmp/company.json", "reason": "verified",
            "artifact_reference": "/tmp/disposition.json",
        }
        index = {
            "schema_version": r.STAGING_INDEX_SCHEMA, "run_id": source["run_id"],
            "complete": True, "total": 1, "counts": {"company_staged_no_person_required": 1},
            "website_overlay_provenance": provenance, "dispositions": [item],
        }
        merged = r.merge_indexes(source, None, index)
        self.assertTrue(merged["complete"])
        broken = copy.deepcopy(index)
        broken["website_overlay_provenance"]["unexplained_verified_unscored_count"] = 1
        with self.assertRaisesRegex(ValueError, "clean overlay provenance"):
            r.merge_indexes(source, None, broken)

    def test_next_action_uses_v2_phase_state(self):
        source = website_discovery()
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            r.route_discovery(source, root)
            self.assertEqual(r.processing_next_action(source, root)["next_action"], "init_enrichment")
            state = m.initialize_state(copy.deepcopy(source))
            (root / "enrichment-state.json").write_text(json.dumps(state))
            self.assertEqual(r.processing_next_action(source, root)["next_action"], "research_enrichment_batch")
            record = state["leads"]["website"]
            record["state"] = "assessment_pending"
            record["enrichment"] = {"website_status": "verified", "official_website_url": "https://example.test", "evidence": [{"evidence_id": "EV-TEST1"}], "missing_information": [], "conflicts": []}
            m._validate_state(state)
            (root / "enrichment-state.json").write_text(json.dumps(state))
            self.assertEqual(r.processing_next_action(source, root)["next_action"], "assessment_enrichment_batch")


if __name__ == "__main__":
    unittest.main(verbosity=2)
