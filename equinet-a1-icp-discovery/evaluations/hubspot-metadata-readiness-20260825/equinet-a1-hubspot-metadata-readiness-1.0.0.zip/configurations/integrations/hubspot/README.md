# Equinet A1 HubSpot Metadata Readiness

**Status:** Metadata snapshot available; live connector and record data unavailable  
**Effective date:** 2026-08-25  
**Scope:** `equinet-a1-icp-discovery`

## Purpose

This package records the HubSpot metadata supplied by Equinet and defines the safe preparation boundary for A1. It does not activate HubSpot access, perform record matching, authorise writes, or establish production acceptance.

## Authoritative files

- `metadata-manifest-v1.json` — source inventory, hashes and observed counts.
- `object-status-model-v1.yaml` — relevant object and pipeline model.
- `ownership-approval-matrix-v1.yaml` — confirmed technical and CRM governance roles.
- `a1-field-mapping-v0.1.yaml` — draft canonical-to-HubSpot read mapping.
- `process-risk-register-v1.yaml` — list and workflow side-effect controls.
- `OPEN-ITEMS.md` — unresolved inputs and integration gates.
- `source-confirmation-20260825.md` — Equinet's Creator, Campaign and administrator confirmations.

The five supplied source files are preserved in `source-snapshots/`.

## Operational state

- HubSpot metadata: available.
- Live HubSpot connector: unavailable.
- Record values and associations: unavailable.
- Duplicate, customer, opportunity, partner, competitor and suppression checks: unavailable.
- HubSpot writes: prohibited.
- List membership changes: prohibited.
- Owner and territory assignment: prohibited without approved rules.

The canonical Prospect Candidate schema remains system-independent. These mappings do not change the approved ICP criteria, evidence-confidence method or scoring model.
