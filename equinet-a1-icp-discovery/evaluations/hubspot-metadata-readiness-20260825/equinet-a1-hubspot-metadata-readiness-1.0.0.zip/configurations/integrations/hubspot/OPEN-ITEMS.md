# Equinet A1 HubSpot Integration Open Items

## Received and recorded

- HubSpot object landscape snapshot.
- Contact, Company, Deal, Ticket, Complaints and Sample Requests property metadata.
- Lifecycle, Lead, Deal, Ticket, Account and Sample Request status models.
- Active and inactive portal user inventory.
- EQUINET and Mustad USA team membership.
- Available record owners and identified non-human accounts.
- Sales Territory values.
- Initial Sales and Marketing workflow and list inventory.
- Confirmation that Campaign is a standard HubSpot object.
- Confirmation that Creator does not exist.
- CRM/business owners and property/object/workflow approvers.
- Unitalk OAuth connection approvers.

## Required before read-only activation

- Authorised OAuth account selected from the approved human OAuth approvers.
- Exact minimum OAuth scopes approved by Equinet and Unitalk.
- Live test of record-level permissions.
- Live verification of Contact–Company–Deal associations.
- Representative field fill-rate and freshness sample.
- Exact list IDs, filters and current membership access for relevant exclusion lists.
- Complete workflow enrolment criteria and action inventory for mapped fields and lists.
- Approved precedence for customer status across Contact, Company and Deal.
- Approved definition of an active opportunity and a previously lost opportunity.
- Approved partner, reseller, dealer and competitor rules.
- Approved consent and suppression precedence.
- Audit capture verification.

## Required before owner or territory recommendations

- State-to-Sales-Territory mapping.
- Owner-assignment and reassignment rules.
- Backup-owner rules.
- Confirmation of which owners are valid for Equinet A1 candidates.

Until then, both `suggested_owner` and `suggested_territory` remain null.

## Required before A1 or A2 review routing

- Named A1 Business Reviewer and backup.
- Approved review queue or durable Unitalk/Twenty/n8n review mechanism.
- A2 handoff trigger and receiving schema.
- Decision, rejection and rework state transitions.

No matching HubSpot enrichment review asset currently exists. Sample Request approval workflows are not valid substitutes.

## Required before any HubSpot write

- Separate approved write mapping.
- Business and technical approval for each write class.
- Workflow and dynamic-list side-effect review.
- Idempotency key and duplicate prevention.
- Reconciliation, rollback and retry design.
- Tamper-evident audit record.
- Production acceptance.

## Useful interim option without OAuth

Equinet may provide dated read-only exports for Contacts, Companies, Deals, associations and relevant list memberships. A deterministic snapshot matcher can then be implemented. Results must be labelled with the snapshot date and must not be represented as live HubSpot checks.
