# Equinet Source Confirmation — 25 August 2026

## Creator and Campaign objects

- `Creator` does not exist in the HubSpot portal.
- A1 does not require a Creator object and must not create or propose one within the A1 scope.
- `Campaign` exists as a standard HubSpot object, not as a custom object.
- A1 must not create a duplicate custom Campaign object.
- The currently confirmed custom objects are `Complaints` and `Sample Requests`.
- Standard Campaign access remains outside the minimum A1 read scope unless a specific approved A1 use case requires it.

## HubSpot administration and technical ownership

- Super Admins: Tahmineh, Faezeh, Lucija and the non-human `Mustad HubSpot` account.
- CRM/business owners: Tahmineh and Lucija.
- Approvers for new properties, objects and workflows: Tahmineh and Lucija.
- Approvers for the Unitalk OAuth connection: Tahmineh, Faezeh and Lucija.

## Approval boundaries

These confirmations do not designate an A1 Business Reviewer, backup reviewer, outreach approver or record-write approver. Super Admin access and OAuth approval do not constitute approval of candidate decisions, scopes beyond the approved minimum, production writes or external communications. Non-human accounts cannot provide human approval.
