#!/usr/bin/env python3
"""Static release checks for the Equinet A1 ICP Discovery SOUL."""

from __future__ import annotations

import sys
from pathlib import Path


PROFILE_DIR = Path(__file__).resolve().parents[1]
SOUL_PATH = PROFILE_DIR / "SOUL.md"

REQUIRED_TEXT = [
    "# Equinet A1 — ICP Discovery",
    "shared Unitalk AI Collaborator",
    "PILOT_READY_NO_INTEGRATION",
    "You never initiate outreach.",
    "## Authoritative configuration",
    "configurations/icp/equinet-icp-v1.yaml",
    "configurations/sources/approved-source-register-v1.yaml",
    "configurations/evidence/evidence-confidence-rules-v1.yaml",
    "configurations/scoring/icp-scoring-model-v1.yaml",
    "configurations/integrations/hubspot/object-status-model-v1.yaml",
    "configurations/integrations/hubspot/ownership-approval-matrix-v1.yaml",
    "configurations/integrations/hubspot/a1-field-mapping-v0.1.yaml",
    "configurations/integrations/hubspot/process-risk-register-v1.yaml",
    "skills/a1-prospect-data-contract/references/prospect-candidate.schema.json",
    "## V1 research method",
    "## Evidence rules",
    "## Candidate data contract",
    "## Confidence calculation",
    "## ICP scoring",
    "## Duplicate and exclusion checks",
    "## Approval and action boundary",
    "## Review and escalation",
    "## A2 handoff",
    "## Output requirements",
    "## Data governance",
    "## Audit requirements",
    "## Error behaviour",
    "## Completion standard",
    "A dated HubSpot metadata snapshot is available",
    "set the HubSpot duplicate/exclusion check to `unavailable`",
    "Twenty is not connected.",
    "Default to **DRAFT FOR APPROVAL**.",
]

FORBIDDEN_TEXT = [
    "You are Hermes Agent",
    "NOT READY FOR PILOT — CONFIGURATION IN PROGRESS",
    "This temporary scaffold must be replaced",
    "automatically send outreach",
    "HubSpot is connected",
    "Twenty is connected",
]

REQUIRED_FILES = [
    "configurations/icp/equinet-icp-v1.yaml",
    "configurations/sources/approved-source-register-v1.yaml",
    "configurations/evidence/evidence-confidence-rules-v1.yaml",
    "configurations/scoring/icp-scoring-model-v1.yaml",
    "configurations/integrations/hubspot/metadata-manifest-v1.json",
    "configurations/integrations/hubspot/object-status-model-v1.yaml",
    "configurations/integrations/hubspot/ownership-approval-matrix-v1.yaml",
    "configurations/integrations/hubspot/a1-field-mapping-v0.1.yaml",
    "configurations/integrations/hubspot/process-risk-register-v1.yaml",
    "skills/a1-prospect-data-contract/references/prospect-candidate.schema.json",
    "skills/a1-prospect-data-contract/scripts/validate_candidate.py",
    "scripts/calculate_candidate_confidence.py",
    "scripts/calculate_icp_score.py",
]


def main() -> int:
    text = SOUL_PATH.read_text(encoding="utf-8")
    errors: list[str] = []

    for required in REQUIRED_TEXT:
        if required not in text:
            errors.append(f"Missing required SOUL text: {required}")
    for forbidden in FORBIDDEN_TEXT:
        if forbidden in text:
            errors.append(f"Forbidden or stale SOUL text present: {forbidden}")
    for relative in REQUIRED_FILES:
        if not (PROFILE_DIR / relative).is_file():
            errors.append(f"Referenced file does not exist: {relative}")

    line_count = len(text.splitlines())
    if line_count > 500:
        errors.append(f"SOUL exceeds 500 lines: {line_count}")

    if errors:
        print(f"INVALID: {SOUL_PATH}")
        for error in errors:
            print(f"- {error}")
        return 1

    print(f"VALID: {SOUL_PATH}")
    print(f"Lines: {line_count}")
    print(f"Required references: {len(REQUIRED_FILES)}")
    print("Deployment status: pilot-ready without live integrations; HubSpot metadata available")
    return 0


if __name__ == "__main__":
    sys.exit(main())
