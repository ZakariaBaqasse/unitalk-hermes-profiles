#!/usr/bin/env python3
"""Build the Equinet A1 HubSpot metadata-readiness release records."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

PROFILE = Path(__file__).resolve().parents[1]
OUTPUT = PROFILE / "evaluations" / "hubspot-metadata-readiness-20260825"
VALIDATION = OUTPUT / "validation-result.json"

CHANGED_ARTIFACTS = [
    "SOUL.md",
    "configurations/operations/a1-runtime-policy-v1.yaml",
    "configurations/integrations/hubspot/README.md",
    "configurations/integrations/hubspot/metadata-manifest-v1.json",
    "configurations/integrations/hubspot/object-status-model-v1.yaml",
    "configurations/integrations/hubspot/ownership-approval-matrix-v1.yaml",
    "configurations/integrations/hubspot/a1-field-mapping-v0.1.yaml",
    "configurations/integrations/hubspot/process-risk-register-v1.yaml",
    "configurations/integrations/hubspot/OPEN-ITEMS.md",
    "configurations/integrations/hubspot/source-confirmation-20260825.md",
    "skills/ranked-prospect-review-package/SKILL.md",
    "skills/ranked-prospect-review-package/scripts/build_review_package.py",
    "scripts/validate_soul.py",
    "scripts/run_wave3_skill_tests.py",
    "scripts/validate_hubspot_metadata_readiness.py",
    "scripts/build_hubspot_metadata_readiness_release.py",
]

PRESERVED_ARTIFACTS = [
    "configurations/icp/equinet-icp-v1.yaml",
    "configurations/scoring/icp-scoring-model-v1.yaml",
    "configurations/evidence/evidence-confidence-rules-v1.yaml",
    "configurations/sources/approved-source-register-v1.yaml",
    "skills/a1-prospect-data-contract/references/prospect-candidate.schema.json",
    "deliverables/step10/A1-V1-OPEN-ITEMS.md",
    "evaluations/step10/release-manifest.json",
]

REGRESSION_SUITES = [
    "run_icp_config_tests.py",
    "run_evidence_confidence_tests.py",
    "run_icp_scoring_tests.py",
    "run_wave1_skill_tests.py",
    "run_wave2_skill_tests.py",
    "run_wave3_skill_tests.py",
    "run_step7_tests.py",
    "validate_step7_runtime_policy.py",
    "run_source_register_tests.py",
    "validate_directory_extraction_foundation.py",
    "validate_directory_extraction_wave1.py",
    "validate_directory_extraction_wave2.py",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def file_record(relative: str) -> dict:
    path = PROFILE / relative
    return {"path": relative, "sha256": sha256(path), "bytes": path.stat().st_size}


def main() -> None:
    validation = json.loads(VALIDATION.read_text(encoding="utf-8"))
    if validation["status"] != "passed":
        raise SystemExit("Metadata-readiness validation has not passed.")

    built_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    manifest = {
        "release_id": "equinet-a1-hubspot-metadata-readiness-1.0.0",
        "profile": "equinet-a1-icp-discovery",
        "built_at": built_at,
        "status": "validated_metadata_ready_no_integration",
        "implementation_authorised_by": "Séverine",
        "authorisation_scope": "Apply the agreed A1 HubSpot metadata-readiness updates",
        "previous_release_reference": "evaluations/step10/release-manifest.json",
        "deployment_status_unchanged": "pilot_ready_no_integration",
        "changes": [
            "Preserved five Equinet-supplied HubSpot source snapshots with hashes.",
            "Recorded object, status, ownership, approval and process metadata.",
            "Added a draft read-only A1-to-HubSpot field mapping.",
            "Added workflow and dynamic-list side-effect controls.",
            "Prevented direct US-state-to-HubSpot-territory mapping.",
            "Preserved null owner recommendation until assignment rules are approved.",
            "Distinguished metadata availability from unavailable live record access in A1 outputs."
        ],
        "unchanged_business_logic": [
            "ICP criteria",
            "ICP scoring weights, thresholds and bands",
            "Evidence-confidence method",
            "Approved public-source policy",
            "Prospect Candidate schema",
            "Human-review requirement",
            "Outreach and CRM-write prohibitions"
        ],
        "validation": {
            "metadata_readiness_checks": validation["checks_total"],
            "metadata_readiness_checks_passed": validation["checks_passed"],
            "regression_suites_passed": REGRESSION_SUITES,
            "deployment_language_findings": validation["language_findings"],
            "external_actions": validation["external_actions"]
        },
        "integration_state": {
            "hubspot_metadata": "available",
            "hubspot_connector": "unavailable",
            "hubspot_record_values": "unavailable",
            "hubspot_associations": "unverified",
            "hubspot_writes": "prohibited",
            "twenty": "unavailable",
            "a2": "not_triggered",
            "n8n": "not_implemented"
        },
        "changed_artifacts": [file_record(path) for path in CHANGED_ARTIFACTS],
        "preserved_artifacts": [file_record(path) for path in PRESERVED_ARTIFACTS]
    }
    OUTPUT.mkdir(parents=True, exist_ok=True)
    (OUTPUT / "release-manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    review = f"""# Equinet A1 HubSpot Metadata-Readiness Review

**Release:** `equinet-a1-hubspot-metadata-readiness-1.0.0`  
**Built:** {built_at}  
**Implementation authorised by:** Séverine  
**Result:** PASS  
**Deployment status:** `pilot_ready_no_integration`

## Implemented

- Preserved and hashed the five supplied HubSpot source snapshots.
- Recorded the standard Campaign object and the absence of a Creator object.
- Recorded lifecycle, Deal, Lead, Account, Ticket and custom-object status models.
- Recorded Super Admin, CRM owner, configuration approver and OAuth approver roles with explicit approval boundaries.
- Recorded non-human accounts and prohibited their use as human approvers.
- Added a draft read-only A1-to-HubSpot field mapping.
- Added workflow, list-membership, consent, owner and territory write guards.
- Corrected review-package generation so a US state is not emitted as a HubSpot Sales Territory.
- Kept owner and territory recommendations null until approved rules exist.
- Updated A1 outputs to distinguish available metadata from unavailable live record checks.

## Preserved unchanged

- ICP criteria and segment logic.
- Scoring weights, thresholds and bands.
- Evidence-confidence rules.
- Approved public-source register.
- Prospect Candidate schema.
- Historical Step 10 release and open-items records.
- Human review, no outreach and no CRM-write boundaries.

## Validation evidence

- HubSpot metadata-readiness checks: {validation['checks_passed']}/{validation['checks_total']} passed.
- Regression suites: {len(REGRESSION_SUITES)}/{len(REGRESSION_SUITES)} passed.
- Deployment-language findings: 0.
- HubSpot reads: 0.
- HubSpot writes: 0.
- Workflow enrolments: 0.
- Outreach actions: 0.

## Remaining limitations

- No live HubSpot connector.
- No Contact, Company, Deal, association or list-membership values.
- No live duplicate, customer, opportunity, partner, competitor or suppression check.
- No approved state-to-territory or owner-assignment rule.
- No named A1 Business Reviewer or backup.
- No approved A1/A2 review queue.
- No production write or outreach authorisation.

## Decision

The patch is technically validated for the existing controlled no-integration pilot. It does not constitute HubSpot integration, production acceptance or permission to perform CRM writes or external communications.
"""
    (OUTPUT / "ACCEPTANCE-REVIEW.md").write_text(review, encoding="utf-8")

    acceptance = {
        "record_id": "A1-HUBSPOT-METADATA-READINESS-20260825",
        "profile": "equinet-a1-icp-discovery",
        "recorded_at": built_at,
        "authorised_by": "Séverine",
        "authorisation_scope": "Implementation of the agreed metadata-readiness patch",
        "technical_validation": "passed",
        "deployment_status": "pilot_ready_no_integration",
        "client_production_acceptance": "not_claimed",
        "hubspot_connector": "unavailable",
        "hubspot_writes": 0,
        "outreach_actions": 0,
        "limitations_reference": "configurations/integrations/hubspot/OPEN-ITEMS.md"
    }
    (OUTPUT / "implementation-record.json").write_text(json.dumps(acceptance, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": "passed", "manifest": str(OUTPUT / "release-manifest.json"), "review": str(OUTPUT / "ACCEPTANCE-REVIEW.md"), "implementation_record": str(OUTPUT / "implementation-record.json")}, indent=2))


if __name__ == "__main__":
    main()
