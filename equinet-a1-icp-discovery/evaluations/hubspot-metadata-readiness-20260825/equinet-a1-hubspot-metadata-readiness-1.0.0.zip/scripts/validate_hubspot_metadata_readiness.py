#!/usr/bin/env python3
"""Validate the Equinet A1 HubSpot metadata-readiness patch."""

from __future__ import annotations

import csv
import hashlib
import json
import re
import sys
from collections import Counter
from pathlib import Path

import yaml

PROFILE = Path(__file__).resolve().parents[1]
HUBSPOT = PROFILE / "configurations" / "integrations" / "hubspot"
OUTPUT = PROFILE / "evaluations" / "hubspot-metadata-readiness-20260825" / "validation-result.json"

IMMUTABLE_HASHES = {
    "configurations/icp/equinet-icp-v1.yaml": "4d28bc35d11a458015f08903b30f0560f204476016508135fe2d126014f16169",
    "configurations/scoring/icp-scoring-model-v1.yaml": "2bb426d73971509b7638ccfe55decb428b3fa11d5ce4b8d3bcc05418b6c75841",
    "configurations/evidence/evidence-confidence-rules-v1.yaml": "5cf2377814ccf3ee635bb279b512778924d2eb42bf1a0a58ec684d90c69c8f80",
    "configurations/sources/approved-source-register-v1.yaml": "d7edc42354c01efcdfd5bdc8df343a8cd9cc33a5189110d4bd6e6214892b632f",
    "skills/a1-prospect-data-contract/references/prospect-candidate.schema.json": "cf4ea0b3729ecaa2b28fa5330917e32f5d911d5894c9c8d396095d6dcc3eb8de",
    "deliverables/step10/A1-V1-OPEN-ITEMS.md": "13f2850eee5661f03e3a7c03627317e9705b9583d8684f7b5b178595fcaee091",
    "evaluations/step10/release-manifest.json": "b2df40670e76ff0b872dd41b95369b519f728fc3fc07a56439b61421d1e5a704",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_yaml(path: Path) -> dict:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def check(condition: bool, label: str, checks: list[dict], errors: list[str]) -> None:
    passed = bool(condition)
    checks.append({"check": label, "passed": passed})
    print(f"{'PASS' if passed else 'FAIL'}: {label}")
    if not passed:
        errors.append(label)


def main() -> int:
    checks: list[dict] = []
    errors: list[str] = []

    manifest = json.loads((HUBSPOT / "metadata-manifest-v1.json").read_text(encoding="utf-8"))
    object_model = load_yaml(HUBSPOT / "object-status-model-v1.yaml")
    ownership = load_yaml(HUBSPOT / "ownership-approval-matrix-v1.yaml")
    mapping = load_yaml(HUBSPOT / "a1-field-mapping-v0.1.yaml")
    risks = load_yaml(HUBSPOT / "process-risk-register-v1.yaml")
    runtime = load_yaml(PROFILE / "configurations" / "operations" / "a1-runtime-policy-v1.yaml")

    check(manifest["status"] == "metadata_snapshot_available_connector_unavailable", "manifest preserves metadata-only status", checks, errors)
    for source in manifest["sources"]:
        path = HUBSPOT / source["path"]
        check(path.is_file(), f"source exists: {source['path']}", checks, errors)
        if path.is_file():
            check(sha256(path) == source["sha256"], f"source hash matches: {source['path']}", checks, errors)

    property_path = HUBSPOT / "source-snapshots" / "property-definitions.csv"
    with property_path.open(newline="", encoding="utf-8-sig") as handle:
        properties = list(csv.DictReader(handle))
    object_counts = Counter(row["Object"] for row in properties)
    expected_counts = {"Company": 227, "Complaints": 28, "Contact": 431, "Deal": 145, "Sample Requests": 41, "Ticket": 78}
    check(len(properties) == 950, "property snapshot has 950 rows", checks, errors)
    check(dict(object_counts) == expected_counts, "property counts match the recorded snapshot", checks, errors)
    unique_lookup = [(row["Object"], row["Internal name"]) for row in properties if row["Unique lookup property"].lower() == "true"]
    check(unique_lookup == [("Contact", "email")], "Contact email is the only declared unique lookup property", checks, errors)

    process_path = HUBSPOT / "source-snapshots" / "sales-marketing-process-inventory.csv"
    with process_path.open(newline="", encoding="utf-8-sig") as handle:
        processes = list(csv.DictReader(handle))
    unique_assets = {(row["Asset type"], row["Name"]) for row in processes}
    enabled = [row for row in processes if row["Asset type"] == "Workflow" and row["Status or list type"] == "Enabled"]
    check(len(processes) == 68, "process inventory has 68 rows", checks, errors)
    check(len(unique_assets) == 66, "process inventory has 66 unique assets", checks, errors)
    check(len(enabled) == 28, "process inventory has 28 enabled workflows", checks, errors)

    check(object_model["objects"]["campaign"]["object_class"] == "standard", "Campaign is recorded as a standard object", checks, errors)
    check(object_model["objects"]["creator"]["exists"] is False, "Creator is recorded as absent and not required by A1", checks, errors)
    check(object_model["objects"]["sample_requests"]["a1_scope"].startswith("out_of_minimum"), "Sample Requests are not an A1 approval mechanism", checks, errors)

    check(ownership["confirmed_roles"]["crm_business_owners"] == ["Tahmineh", "Lucija"], "CRM business owners are recorded", checks, errors)
    check(ownership["confirmed_roles"]["property_object_workflow_approvers"] == ["Tahmineh", "Lucija"], "CRM configuration approvers are recorded", checks, errors)
    check(ownership["confirmed_roles"]["unitalk_oauth_connection_approvers"] == ["Tahmineh", "Faezeh", "Lucija"], "OAuth approvers are recorded", checks, errors)
    check("Mustad HubSpot" in ownership["non_human_accounts"], "Mustad HubSpot is protected as a non-human account", checks, errors)
    check(ownership["runtime_rules"]["suggested_owner"] is None, "suggested owner remains null", checks, errors)
    check(ownership["runtime_rules"]["suggested_territory"] is None, "suggested territory remains null", checks, errors)

    check(mapping["connector_status"] == "unavailable", "field mapping does not activate the connector", checks, errors)
    check(mapping["writes_authorised"] is False, "field mapping does not authorise writes", checks, errors)
    non_equivalent = {entry["hubspot_property"] for entry in mapping["semantic_non_equivalences"]}
    check({"hs_ideal_customer_profile", "hs_predictivecontactscore_v2", "data_quality", "hs_is_enriched"} <= non_equivalent, "native HubSpot fields are not conflated with A1 semantics", checks, errors)

    check(risks["high_risk_controls"]["list_membership_write"] == "prohibited", "list membership writes remain prohibited", checks, errors)
    check(risks["confirmed_absences"]["enrichment_review_asset"] == "not_found", "missing enrichment review asset is recorded", checks, errors)
    check(risks["confirmed_absences"]["sequence_resources"] == "not_found_in_current_inventory", "missing sequences do not imply missing workflow outreach", checks, errors)

    hubspot_runtime = runtime["hubspot_metadata"]
    check(runtime["policy_version"] == "1.8.0", "runtime policy version is 1.8.0", checks, errors)
    check(hubspot_runtime["status"] == "metadata_snapshot_available_connector_unavailable", "runtime distinguishes metadata from connection", checks, errors)
    check(hubspot_runtime["suggested_owner"] is None and hubspot_runtime["suggested_territory"] is None, "runtime prevents owner and territory inference", checks, errors)
    required_prohibitions = {
        "hubspot_write", "hubspot_list_membership_change", "hubspot_workflow_enrolment",
        "hubspot_owner_assignment", "hubspot_territory_assignment", "hubspot_consent_or_marketing_status_change",
    }
    check(required_prohibitions <= set(runtime["tool_policy"]["prohibited_actions"]), "runtime contains all HubSpot write-side prohibitions", checks, errors)

    soul = (PROFILE / "SOUL.md").read_text(encoding="utf-8")
    check("A dated HubSpot metadata snapshot is available" in soul, "SOUL records metadata availability", checks, errors)
    check("Keep `recommendation.suggested_territory` null" in soul, "SOUL prevents direct state-to-territory mapping", checks, errors)
    check("non-human accounts and cannot provide human approval" in soul, "SOUL protects non-human approval boundary", checks, errors)

    builder = (PROFILE / "skills" / "ranked-prospect-review-package" / "scripts" / "build_review_package.py").read_text(encoding="utf-8")
    check('"suggested_territory": None' in builder, "review builder emits null suggested territory", checks, errors)
    check('"suggested_territory": candidate_location.get("state_region")' not in builder, "review builder no longer maps state directly to territory", checks, errors)
    check("HubSpot metadata is available" in builder, "review output distinguishes metadata from live access", checks, errors)

    for relative, expected in IMMUTABLE_HASHES.items():
        check(sha256(PROFILE / relative) == expected, f"immutable artifact unchanged: {relative}", checks, errors)

    authored = [
        PROFILE / "SOUL.md",
        PROFILE / "configurations" / "operations" / "a1-runtime-policy-v1.yaml",
        HUBSPOT / "README.md",
        HUBSPOT / "source-confirmation-20260825.md",
        HUBSPOT / "object-status-model-v1.yaml",
        HUBSPOT / "ownership-approval-matrix-v1.yaml",
        HUBSPOT / "a1-field-mapping-v0.1.yaml",
        HUBSPOT / "process-risk-register-v1.yaml",
        HUBSPOT / "OPEN-ITEMS.md",
        PROFILE / "skills" / "ranked-prospect-review-package" / "SKILL.md",
    ]
    french_markers = re.compile(r"\b(?:données|propriété|utilisateur|aucune|indisponible|à confirmer|doit être|étape)\b", re.IGNORECASE)
    findings = []
    for path in authored:
        for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
            if french_markers.search(line):
                findings.append({"path": str(path.relative_to(PROFILE)), "line": line_number, "text": line})
    check(not findings, "deployment-language audit finds no unintended French in authored active artifacts", checks, errors)

    result = {
        "status": "passed" if not errors else "failed",
        "suite": "Equinet A1 HubSpot metadata-readiness validation",
        "checks_total": len(checks),
        "checks_passed": sum(item["passed"] for item in checks),
        "errors": errors,
        "language_findings": findings,
        "external_actions": {"hubspot_reads": 0, "hubspot_writes": 0, "workflow_enrolments": 0, "outreach": 0},
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
